
Signs - v1 2022-06-15 8:12pm
==============================

This dataset was exported via roboflow.ai on June 15, 2022 at 6:13 PM GMT

It includes 741 images.
Signs are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


